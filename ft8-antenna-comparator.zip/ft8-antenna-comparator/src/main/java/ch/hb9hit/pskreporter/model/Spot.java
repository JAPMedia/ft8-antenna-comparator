
package ch.hb9hit.pskreporter.model;

public class Spot {
    private String callsign;
    private String grid;
    private int snr;
}
