
package ch.hb9hit.pskreporter.service;

public class PskReporterService {
    // Logique de récupération et de comparaison à venir
}
